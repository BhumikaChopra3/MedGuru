package com.example.medguru.ui.sanitaryItems

import androidx.lifecycle.ViewModel

class SanitaryItemsViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}